package com.licht_meilleur.the_end_of_dragon.entity;

import com.geckolib.animatable.manager.AnimatableManager;
import com.geckolib.animation.AnimationController;
import com.geckolib.animation.RawAnimation;
import com.geckolib.animation.object.PlayState;
import com.licht_meilleur.the_end_of_dragon.entity.collision.DragonCollisionBox;
import com.licht_meilleur.the_end_of_dragon.entity.collision.DragonCollisionPart;
import com.licht_meilleur.the_end_of_dragon.entity.collision.DragonCollisionSampler;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class TheEndOfDragonCollisionEntity extends TheEndOfDragonEntity {


    public TheEndOfDragonCollisionEntity(EntityType<? extends Monster> type, Level level) {
        super(type, level);
    }

    private DragonState renderState = DragonState.IDLE;
    private int animationAgeTicks = 0;


    private int coreEntityId = -1;


    @Override
    public void syncFromCore(TheEndOfDragonCoreEntity core) {
        super.syncFromCore(core);
        this.renderState = core.getDragonState();
        this.animationAgeTicks = core.getDragonStateAgeTicks();
        this.dragonState = core.getDragonState();

        this.setXRot(core.getVisualPitch());
        this.xRotO = core.getVisualPitch();

        this.coreEntityId = core.getId();


    }

    private TheEndOfDragonCoreEntity getCore() {
        if (coreEntityId == -1) return null;

        var entity = this.level().getEntity(coreEntityId);
        return entity instanceof TheEndOfDragonCoreEntity core ? core : null;
    }

    @Override
    public boolean isPickable() {
        return true;
    }

    @Override
    public boolean isAttackable() {
        return true;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean hurtServer(
            ServerLevel level,
            DamageSource source,
            float damage
    ) {
        TheEndOfDragonCoreEntity core =
                findOwnerCore(level);

        if (core == null) {
            return false;
        }

        return core.hurtFromPart(
                level,
                source,
                damage,
                DragonCollisionPart.UPPER_BODY
        );
    }

    private TheEndOfDragonCoreEntity findOwnerCore(
            ServerLevel level
    ) {
        UUID ownerUuid = this.getOwnerCoreUuid();

        if (ownerUuid == null) {
            return null;
        }

        Entity entity = level.getEntity(ownerUuid);

        if (entity instanceof TheEndOfDragonCoreEntity core
                && !core.isRemoved()
                && core.isAlive()) {
            return core;
        }

        return null;
    }


    private float flightPitch = 0.0F;

    public float getFlightPitch() {
        return this.flightPitch;
    }

    @Override
    protected DragonState getAnimationState() {
        return getSyncedRenderState();
    }

    public DragonState getAnimationStateForCollision() {
        return this.renderState;
    }

    public int getAnimationAgeTicks() {
        return this.animationAgeTicks;
    }

    private DragonState dragonState = DragonState.IDLE;

    public DragonState getDragonState() {
        return dragonState;
    }


    @Override
    public void tick() {
        super.tick();



        if (!this.level().isClientSide()) {
            for (DragonCollisionBox collisionBox : this.getCollisionBoxes()) {
                var players = this.level().getEntitiesOfClass(
                        net.minecraft.world.entity.player.Player.class,
                        collisionBox.box()
                );

                for (var player : players) {
                    if (!collisionBox.obb().intersects(player.getBoundingBox())) {
                        continue;
                    }

                    player.hurtServer(
                            (net.minecraft.server.level.ServerLevel) this.level(),
                            this.damageSources().mobAttack(this),
                            1.0F
                    );

                    //System.out.println("[TED HIT OBB] part=" + collisionBox.part() + " player=" + player.getName().getString());
                }
            }
        }

        if (!this.level().isClientSide()) {
            //this.debugDrawCollisionBoxes();
            this.pushPlayersOutOfCollisionBoxes();
        }
    }



    private void syncRotationFromParent() {
        if (!(this.getVehicle() instanceof TheEndOfDragonCoreEntity parent)) {
            return;
        }

        float yaw = parent.getYRot();
        float pitch = parent.getXRot();

        this.setYRot(yaw);
        this.setYBodyRot(yaw);
        this.setYHeadRot(yaw);
        this.setXRot(pitch);

        this.yRotO = parent.yRotO;
        this.yBodyRotO = parent.yBodyRotO;
        this.yHeadRotO = parent.yHeadRotO;
        this.xRotO = parent.xRotO;

        /*
        if (this.tickCount % 20 == 0) {
            System.out.println("[TED CHILD ROT] " + this.getClass().getSimpleName()
                    + " yaw=" + this.getYRot()
                    + " pitch=" + this.getXRot());
        }

         */
    }

    public List<DragonCollisionBox> getCollisionBoxes() {
        return DragonCollisionSampler.buildBoxes(this);
    }

    private void pushPlayersOutOfCollisionBoxes() {
        if (this.level().isClientSide()) {
            return;
        }

        for (DragonCollisionBox collisionBox : this.getCollisionBoxes()) {
            AABB box = collisionBox.box();

            var players = this.level().getEntitiesOfClass(
                    net.minecraft.world.entity.player.Player.class,
                    box.inflate(0.05D)
            );

            for (var player : players) {
                AABB playerBox = player.getBoundingBox();

                if (!collisionBox.obb().intersects(playerBox)) {
                    continue;
                }

                double pushX1 = Math.abs(playerBox.maxX - box.minX);
                double pushX2 = Math.abs(box.maxX - playerBox.minX);
                double pushZ1 = Math.abs(playerBox.maxZ - box.minZ);
                double pushZ2 = Math.abs(box.maxZ - playerBox.minZ);

                double minPush = Math.min(
                        Math.min(pushX1, pushX2),
                        Math.min(pushZ1, pushZ2)
                );

                double pushX = 0.0D;
                double pushZ = 0.0D;

                if (minPush == pushX1) {
                    pushX = -(pushX1 + 0.05D);
                } else if (minPush == pushX2) {
                    pushX = pushX2 + 0.05D;
                } else if (minPush == pushZ1) {
                    pushZ = -(pushZ1 + 0.05D);
                } else {
                    pushZ = pushZ2 + 0.05D;
                }

                player.setDeltaMovement(
                        player.getDeltaMovement().add(pushX * 0.35D, 0.0D, pushZ * 0.35D)
                );

                player.hurtMarked = true;

                //System.out.println("[TED PUSH] part=" + collisionBox.part());
            }
        }
    }

    private void debugDrawCollisionBoxes() {
        if (!(this.level() instanceof net.minecraft.server.level.ServerLevel serverLevel)) {
            return;
        }

        if (this.tickCount % 2 != 0) {
            return;
        }

        var boxes = this.getCollisionBoxes();

        if (this.tickCount % 40 == 0) {
            //System.out.println("[TED COLLISION DEBUG] boxes=" + boxes.size());
        }

        for (var collisionBox : boxes) {
            //判定表示
            drawAabb(serverLevel, collisionBox.box());
        }
    }

    private void drawAabb(net.minecraft.server.level.ServerLevel level, net.minecraft.world.phys.AABB box) {
        double step = 0.35D;

        drawLine(level, box.minX, box.minY, box.minZ, box.maxX, box.minY, box.minZ, step);
        drawLine(level, box.minX, box.minY, box.maxZ, box.maxX, box.minY, box.maxZ, step);
        drawLine(level, box.minX, box.maxY, box.minZ, box.maxX, box.maxY, box.minZ, step);
        drawLine(level, box.minX, box.maxY, box.maxZ, box.maxX, box.maxY, box.maxZ, step);

        drawLine(level, box.minX, box.minY, box.minZ, box.minX, box.maxY, box.minZ, step);
        drawLine(level, box.maxX, box.minY, box.minZ, box.maxX, box.maxY, box.minZ, step);
        drawLine(level, box.minX, box.minY, box.maxZ, box.minX, box.maxY, box.maxZ, step);
        drawLine(level, box.maxX, box.minY, box.maxZ, box.maxX, box.maxY, box.maxZ, step);

        drawLine(level, box.minX, box.minY, box.minZ, box.minX, box.minY, box.maxZ, step);
        drawLine(level, box.maxX, box.minY, box.minZ, box.maxX, box.minY, box.maxZ, step);
        drawLine(level, box.minX, box.maxY, box.minZ, box.minX, box.maxY, box.maxZ, step);
        drawLine(level, box.maxX, box.maxY, box.minZ, box.maxX, box.maxY, box.maxZ, step);
    }

    private void drawLine(
            net.minecraft.server.level.ServerLevel level,
            double x1, double y1, double z1,
            double x2, double y2, double z2,
            double step
    ) {
        double dx = x2 - x1;
        double dy = y2 - y1;
        double dz = z2 - z1;

        double length = Math.sqrt(dx * dx + dy * dy + dz * dz);
        int count = Math.max(1, (int) (length / step));

        for (int i = 0; i <= count; i++) {
            double t = (double) i / (double) count;

            level.sendParticles(
                    net.minecraft.core.particles.ParticleTypes.END_ROD,
                    x1 + dx * t,
                    y1 + dy * t,
                    z1 + dz * t,
                    1,
                    0.0D,
                    0.0D,
                    0.0D,
                    0.0D
            );
        }
    }



}