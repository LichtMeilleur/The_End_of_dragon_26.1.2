package com.licht_meilleur.the_end_of_dragon.entity;

public enum DragonState {
    IDLE,
    WALK,

    FLY_START,
    FLY,
    FLY_LEFT,
    FLY_RIGHT,
    FLY_SHOT,

    FALL,
    LANDING,
    SUPER_LANDING,

    ORB_OF_ANNIHILATION,
    ROAR_OF_OBLITERATION,
    FLAMES_OF_RAGNAROK,
    LIGHT_OF_DESTRUCTION,
    PHOTON_BLASTER,
    BLASTER_TACKLE,
    TAIL_WHIP,
    JUDGMENT_RAY,
    PHOTON_BUSTER,


    FLY_ASCEND,
    FLY_DESCEND,


    INTRO_RISE,
    INTRO_WAIT_PORTAL,
    INTRO_FLY_TO_PORTAL,
    INTRO_DIVE_TO_PORTAL,
    INTRO_SUPER_LANDING,

    FIGURE_EIGHT,

    RECOVERY_ASCEND,
    RECOVERY_RETURN,
    RECOVERY_DIVE,



    DEAD

}